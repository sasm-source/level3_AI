import os
from dotenv import load_dotenv
from src.rag import prepare_data, create_vector_store
from src.agent import create_agent
from src.evaluation import evaluate_response

print('main module loaded')

load_dotenv()

def main():
    print('Main started')
    data_dir = os.path.join(os.path.dirname(__file__), 'data')
    documents = prepare_data(data_dir)
    vectorstore = create_vector_store(documents)
    agent = create_agent(vectorstore)
    
    # Test queries
    test_cases = [
        {"query": "What is the capital of France?", "expected": "Paris"},
        {"query": "What is Python?", "expected": "A programming language"},
        {"query": "Calculate 2 + 2", "expected": "4"}
    ]
    
    for case in test_cases:
        try:
            result = agent.invoke({"input": case["query"]})
        except Exception as e:
            print(f"Agent invoke error: {e}")
            import traceback
            traceback.print_exc()
            continue
        if isinstance(result, dict):
            response = result.get("output") or result.get("response") or str(result)
        else:
            response = str(result)
        metrics = evaluate_response(case["query"], response, case["expected"])
        print(f"Query: {case['query']}")
        print(f"Response: {response}")
        print(f"Metrics: {metrics}")
        print("---")

if __name__ == "__main__":
    main()