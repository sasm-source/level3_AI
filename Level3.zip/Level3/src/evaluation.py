from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer

model = SentenceTransformer('all-MiniLM-L6-v2')

def evaluate_response(query, response, expected_answer):
    # Simple relevance check using embeddings
    query_emb = model.encode([query])
    response_emb = model.encode([response])
    expected_emb = model.encode([expected_answer])
    
    relevance = cosine_similarity(query_emb, response_emb)[0][0]
    accuracy = cosine_similarity(response_emb, expected_emb)[0][0]
    
    return {
        'relevance': relevance,
        'accuracy': accuracy,
        'clarity': len(response.split()) / 100  # Simple proxy for clarity
    }