from langchain.agents import create_agent as create_agent_graph
from langchain.tools import tool
from .rag import create_rag_retriever
from .tools import tools

def create_agent(vectorstore):
    retriever = create_rag_retriever(vectorstore)
    
    # Add RAG as a tool
    @tool
    def rag(query: str) -> str:
        """Retrieve document chunks related to query and return them as text."""
        docs = retriever.get_relevant_documents(query)
        return "\n".join([doc.page_content for doc in docs])
    
    all_tools = tools + [rag]
    
    agent = create_agent_graph(
        model="openai:gpt-4o-mini",
        tools=all_tools,
        system_prompt="You are a helpful AI agent using RAG and tools.",
        debug=False
    )
    return agent