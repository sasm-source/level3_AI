import math
from langchain.tools import tool
from langchain_community.utilities import SerpAPIWrapper

@tool
def calculator(expression: str) -> str:
    """Evaluate a simple mathematical expression and return result."""
    try:
        return str(eval(expression))
    except Exception:
        return "Error in calculation"


@tool
def web_search(query: str) -> str:
    """Perform a web search using SerpAPI and return the results."""
    # Note: Requires SERPAPI_API_KEY in .env
    search = SerpAPIWrapper()
    return search.run(query)

tools = [calculator, web_search]