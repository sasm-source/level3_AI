import os
from langchain_community.document_loaders import TextLoader
from langchain_text_splitters import CharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAI

def prepare_data(data_dir):
    documents = []
    for file in os.listdir(data_dir):
        if file.endswith('.txt'):
            loader = TextLoader(os.path.join(data_dir, file))
            documents.extend(loader.load())
    return documents

def create_vector_store(documents):
    text_splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=0)
    texts = text_splitter.split_documents(documents)
    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_documents(texts, embeddings)
    return vectorstore

def create_rag_retriever(vectorstore):
    return vectorstore.as_retriever()