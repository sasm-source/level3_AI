# AI Agent with RAG Pipeline

This project implements a simple AI agent that covers the following components for an AI course assignment:

## Components

1. **Data Preparation & Contextualization**: Sample documents are loaded and prepared for the agent.

2. **RAG Pipeline Design**: Uses OpenAI embeddings and FAISS vector store for retrieval.

3. **Reasoning & Reflection**: The agent uses LangChain's ZERO_SHOT_REACT_DESCRIPTION agent for reasoning.

4. **Tool-Calling Mechanisms**: Includes calculator and web search tools.

5. **Evaluation**: Simple metrics for accuracy, relevance, and clarity using sentence embeddings.

## Setup

1. Install dependencies: `pip install -r requirements.txt`

2. Set your OpenAI API key in `.env`

3. Run the project: `python main.py`
	- On Windows, use `py main.py` if python is not in PATH.
	- For web search tool, add SERPAPI_API_KEY to .env (optional).

## Files

- `main.py`: Entry point
- `src/rag.py`: RAG pipeline
- `src/agent.py`: Agent setup
- `src/tools.py`: Tool definitions
- `src/evaluation.py`: Evaluation metrics
- `data/`: Sample documents
- `requirements.txt`: Dependencies